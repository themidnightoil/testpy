"""
Code illustration: 4.02
@ Tkinter GUI Application Development Blueprints
"""
class ChessError(Exception): pass
