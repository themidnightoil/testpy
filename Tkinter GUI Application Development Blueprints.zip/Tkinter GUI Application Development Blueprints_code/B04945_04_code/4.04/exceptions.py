"""
Code illustration: 4.04
@ Tkinter GUI Application Development Blueprints
"""
class ChessError(Exception): pass
