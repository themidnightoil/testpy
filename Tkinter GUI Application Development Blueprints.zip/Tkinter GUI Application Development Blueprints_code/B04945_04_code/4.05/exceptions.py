"""
Code illustration: 4.05
@ Tkinter GUI Application Development Blueprints
"""
class ChessError(Exception): pass
