"""
Code illustration: 4.01

@ Tkinter GUI Application Development Blueprints
"""

NUMBER_OF_ROWS = 8
NUMBER_OF_COLUMNS = 8
DIMENSION_OF_EACH_SQUARE = 64 # denoting 64 pixels
BOARD_COLOR_1 =  "#DDB88C"
BOARD_COLOR_2 = "#A66D4F"

    
