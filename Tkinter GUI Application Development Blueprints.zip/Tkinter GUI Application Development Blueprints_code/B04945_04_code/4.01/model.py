"""
Code illustration: 4.01

@ Tkinter GUI Application Development Blueprints
"""
from configurations import *


class Model():

    def __init__(self):
        pass
