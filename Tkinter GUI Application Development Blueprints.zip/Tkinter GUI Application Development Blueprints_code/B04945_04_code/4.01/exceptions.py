"""
Code illustration: 4.01
@ Tkinter GUI Application Development Blueprints
"""
class ChessError(Exception): pass
