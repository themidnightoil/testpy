====================================================================
Code Readme
Tkinter GUI Application Development Blueprints
Chapter 7: Multiple Fun Projects
====================================================================
Code Description:
Code 7.01: 			Screensaver
Code 7.02: 			Race condition demo
Code 7.03: 			Avoiding race condition with locks
Code 7.04: 			Threading with Queue Simple Demo
Code 7.05: 			Snake Game
Code 7.06: 			Fetching web content with urllib -  demo
Code 7.07: 			Weather Reporter
Code 7.08: 			Socket Demo
Code 7.09: 			Port Scanner
Code 7.10: 			Chat Server
Code 7.11: 			Chat Client
Code 7.12: 			Phone Book
Code 7.13: 			Pie Chart	
Code 7.14: 			Bar Graph
Code 7.15: 			Scatter Plot
Code 7.16: 			Embedding Matplotlib graph on Tkinter
Code 7.17: 			3D Graphics

Directory 'icons' contains all images used in the programs
Directory 'weatherimages' contains all images used by Weather Reporter program
