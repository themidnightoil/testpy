"""
Code illustration: 1.01
Your first GUI application - the top level window
Tkinter GUI Application Development Blueprints
""" 

from tkinter import * 
root = Tk()            
root.mainloop()        

