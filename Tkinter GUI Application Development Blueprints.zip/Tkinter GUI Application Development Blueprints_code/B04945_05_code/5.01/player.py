"""
Code illustration: 5.01

@Tkinter GUI Application Development Blueprints
""" 

import pyglet

class Player:
    
    def __init__(self):
        pass        
   
    
