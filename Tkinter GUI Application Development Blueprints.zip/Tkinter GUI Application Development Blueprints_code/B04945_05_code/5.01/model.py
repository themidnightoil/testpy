"""
Code illustration: 5.01

@Tkinter GUI Application Development Blueprints
""" 

class Model:
    
    def __init__(self):
        pass
    
    
